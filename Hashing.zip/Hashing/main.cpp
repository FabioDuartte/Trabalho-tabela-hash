#include <cstdlib>
#include <string>
#include <iostream>
#include "SeparateChainingHashTable.h"
#include "QuadraticProbingHashTable.h"
#include "Aluno.h"

using namespace std;
int hash0 (int key, int tableSize) {
	return key%tableSize;
}
int hash1 (string key, int tableSize) {
     int hashValue=0;
     for (int i=0;i<key.length();i++) {
           hashValue+=key[i];
      }
      return hashValue%tableSize;
}
int hash2 (string key, int tableSize) {
     int hashValue;
     hashValue=key[0]+key[1]*27+key[2]*729;     
     return hashValue%tableSize;
}
int hash3 (string key, int tableSize) {
     int hashValue=0;
     // resolve o polinômio para x=37
     for (int i=0;i<key.length();i++)
           hashValue=37*hashValue+key[i];
     // calcula o código hash
     hashValue%=tableSize;
     // trata um possível int overflow
     if (hashValue<0)
 	hashValue+=tableSize;        
     return  hashValue;          
}        

main(int argc, char** argv) { 
    SeparateChainingHashTable<Aluno> hashTable=SeparateChainingHashTable<Aluno>(11);
 //   hashTable.print();
       
    
    hashTable.insert(Aluno("Jorge"));
    hashTable.insert(Aluno("Jesus"));
    hashTable.insert(Aluno("Maria"));
    hashTable.insert(Aluno("Pedro"));
    hashTable.insert(Aluno("Judas"));
    hashTable.insert(Aluno("José"));
    hashTable.insert(Aluno("Madalena"));
    
    hashTable.print();
   /*
    
    hashTable.remove(Aluno("Jorge"));
    hashTable.print();
     */
}
